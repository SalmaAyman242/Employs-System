/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication13;

/**
 *
 * @author Lenovo
 */
public class PartTimeEmployee {
    private int id;
    private String name;
    private double hourlyRate;
    private int hoursWorked;
    
    public double calculateSalary(){
     double salary= hourlyRate*hoursWorked;
     return salary;
    }
    
    public void displayDetails(){
        System.out.println("the id of the employee: "+getId());
        System.out.println("the name of the employee: "+getName());
        System.out.println("the number of hours worked of the employee: "+ getHoursWorked());
        System.out.println("the hourly rate of the employee is : "+getHourlyRate());
        System.out.println("the total salary of the employee: "+ calculateSalary()+"\n");
    }

    public PartTimeEmployee(int id, String name, double hourlyRate, int hoursWorked) {
        this.id = id;
        this.name = name;
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
    
    
}
