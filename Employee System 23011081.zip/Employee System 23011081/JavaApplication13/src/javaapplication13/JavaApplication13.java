/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication13;

public class JavaApplication13 {
    public static void main(String[] args) {
    
    FullTimeEmployee f1=new FullTimeEmployee(230,"Ahmed",2000);
    PartTimeEmployee p1=new PartTimeEmployee(231,"Yasser",0.7,1200);
    ContractEmployee c1=new ContractEmployee(232,"Salma",150000);
        
    f1.displayDetails();
    p1.displayDetails();
    c1.displayDetails();
        
    }
    
}
