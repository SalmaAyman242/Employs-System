/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication13;

/**
 *
 * @author Lenovo
 */
public class ContractEmployee {
    private int id;
    private String name;
    private double totalSalary;
    
    public double calculateSalary(){
       return totalSalary;  
      }
    public void displayDetails(){
      System.out.println("the id of the employee: "+getId());
      System.out.println("the name of the employee: "+getName());
      System.out.println("the total salary of the employee: "+ calculateSalary()+"\n");
        
    }

    public ContractEmployee(int id, String name, double totalSalary) {
        this.id = id;
        this.name = name;
        this.totalSalary = totalSalary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /*public double getTotalSalary() {
        return totalSalary;
    }*/

    public void setTotalSalary(double totalSalary) {
        this.totalSalary = totalSalary;
    }

        
    
}
